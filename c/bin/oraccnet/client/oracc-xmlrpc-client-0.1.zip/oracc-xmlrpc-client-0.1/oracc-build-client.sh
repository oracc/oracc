#!/bin/sh
FLAGS=p:

## Options
args=`getopt $FLAGS $*`
echo args=$args
for args; do
    case "$args" in
	-p ) project=$2
	     shift ; shift ;;
	-- ) shift; break ;;
    esac
done

if [ $? != 0 -o $# != 0 ] ; then
  echo ""
  echo "Usage: oracc-build-client.sh {args}"
  echo ""
  exit 0
fi

## Check we are in proper project location
if [ ! -r "00lib/config.xml" ]; then
    echo oracc-build-client.sh: not in an Oracc project directory. Stop.
    exit 1
fi

## Check current project is arg project
cproject=`tr '\n' ' ' <00lib/config.xml | tr '>' '\n' | grep '<project ' | sed 's/^.*n=//' | tr -d '" '`
if [ "$cproject" != "$project" ]; then
    echo oracc-build-client.sh: current project is $cproject but build request is for $project. Stop.
    exit 1
fi

## User/Pass
. ~/.oracc-user

## Package
version=`cat .version`
zip=request.zip
zip -q $zip 00atf/*.atf 00lib/config.xml 00lib/*.glo

## Send
echo oracc-client -m build -u $user -P $pass -p $project -v $version -Mfile:zip=$zip
oracc-client -m build -s http://build.oracc.org/xmlrpc -u $user -P $pass -p $project -v $version -Mfile:zip=$zip

## Report
cat build.log
