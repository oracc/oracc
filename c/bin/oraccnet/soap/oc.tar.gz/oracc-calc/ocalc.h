//gsoap ocalc service name: ocalc
//gsoap ocalc service namespace: http://oracc.org/wsdl/ocalc.wsdl
//gsoap ocalc service location: http://build.oracc.org/ws/oracc-calc.cgi
//gsoap ocalc schema namespace: urn:ocalc
int ocalc__add(double a, double b, double *result);  
int ocalc__sub(double a, double b, double *result);  
int ocalc__sqrt(double a, double *result);
